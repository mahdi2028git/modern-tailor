# Modern Tailor – Laravel version

English / Persian (RTL) landing page with a contact form saved to the database.
Built as an overlay for Laravel 11 or 12 — it does not include Laravel's core
framework files, just the app-specific pieces.

## Setup

1. Create a fresh Laravel app:

       composer create-project laravel/laravel modern-tailor
       cd modern-tailor

2. Copy everything from this folder (except this README) into the new
   project, merging folders and replacing `routes/web.php`.

3. Register the locale middleware in `bootstrap/app.php`:

       ->withMiddleware(function (Middleware $middleware): void {
           $middleware->web(append: [
               \App\Http\Middleware\SetLocale::class,
           ]);
       })

4. Run the migration and start the server:

       php artisan migrate
       php artisan serve

5. Open http://127.0.0.1:8000. Submitted contact messages are stored in the
   `contact_messages` table.

## What's included

- `routes/web.php` – home page, language switch, contact form POST
- `app/Http/Controllers/PageController.php` – page logic
- `app/Http/Middleware/SetLocale.php` – reads language from the session
- `app/Models/ContactMessage.php` + migration – stores contact form submissions
- `lang/en/site.php`, `lang/fa/site.php` – all page text, English and Persian
- `resources/views/layouts/app.blade.php`, `home.blade.php` – the page itself
- `public/css/site.css` – styling (light/dark mode, RTL support)

## Notes

- Language switching uses real routes (`/lang/en`, `/lang/fa`) and session
  storage, rather than client-side JavaScript — works even with JS disabled.
- The contact form is a real POST request with server-side validation
  (name, email required) and CSRF protection, instead of a fake JS alert.
- Persian pages render right-to-left with a different font stack, matching
  the original design.
