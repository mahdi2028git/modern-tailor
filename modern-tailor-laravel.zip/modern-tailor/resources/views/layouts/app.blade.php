<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" dir="{{ app()->getLocale() === 'fa' ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>@yield('title', __('site.title'))</title>
    <link rel="stylesheet" href="{{ asset('css/site.css') }}">
</head>
<body class="{{ app()->getLocale() === 'fa' ? 'rtl' : '' }}">
<div class="wrap">
    <nav>
        <span class="logo">{{ __('site.brand') }}</span>
        <span>
            <a href="#services">{{ __('site.nav_services') }}</a>
            <a href="#contact">{{ __('site.nav_contact') }}</a>
            <a class="lang" href="{{ route('lang', app()->getLocale() === 'en' ? 'fa' : 'en') }}">{{ __('site.switch') }}</a>
        </span>
    </nav>

    @yield('content')

    @php
        $year = app()->getLocale() === 'fa'
            ? strtr(date('Y'), '0123456789', '۰۱۲۳۴۵۶۷۸۹')
            : date('Y');
    @endphp
    <footer>{{ __('site.footer', ['year' => $year]) }}</footer>
</div>
</body>
</html>
