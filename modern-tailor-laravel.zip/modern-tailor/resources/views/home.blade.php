@extends('layouts.app')

@section('content')
<header>
    <h1>{{ __('site.hero_title') }}</h1>
    <p class="lead">{{ __('site.hero_lead') }}</p>
    <a class="btn" href="#contact">{{ __('site.hero_cta') }}</a>
</header>

<section id="services">
    <h2>{{ __('site.services') }}</h2>
    <div class="grid">
        @foreach ([1, 2, 3] as $i)
            <div class="card">
                <h3>{{ __("site.s{$i}_title") }}</h3>
                <p>{{ __("site.s{$i}_text") }}</p>
            </div>
        @endforeach
    </div>
</section>

<section>
    <div class="quote">
        {{ __('site.quote') }}
        <small>{{ __('site.quote_by') }}</small>
    </div>
</section>

<section id="contact">
    <h2>{{ __('site.contact') }}</h2>

    <form method="POST" action="{{ route('contact') }}">
        @csrf
        <input name="name" value="{{ old('name') }}" placeholder="{{ __('site.ph_name') }}" required>
        @error('name')<div class="error">{{ $message }}</div>@enderror

        <input name="email" type="email" value="{{ old('email') }}" placeholder="{{ __('site.ph_email') }}" required>
        @error('email')<div class="error">{{ $message }}</div>@enderror

        <textarea name="message" rows="4" placeholder="{{ __('site.ph_message') }}">{{ old('message') }}</textarea>
        @error('message')<div class="error">{{ $message }}</div>@enderror

        <button class="btn" type="submit" style="margin-top:0">{{ __('site.send') }}</button>
    </form>

    @if (session('status'))
        <div class="flash">{{ session('status') }}</div>
    @endif
</section>
@endsection
