<?php

namespace App\Http\Controllers;

use App\Models\ContactMessage;
use Illuminate\Http\Request;

class PageController extends Controller
{
    public function home()
    {
        return view('home');
    }

    public function setLocale(string $locale)
    {
        session(['locale' => $locale]);

        return redirect()->route('home');
    }

    public function contact(Request $request)
    {
        $data = $request->validate([
            'name'    => 'required|string|max:100',
            'email'   => 'required|email|max:150',
            'message' => 'nullable|string|max:2000',
        ]);

        ContactMessage::create($data);

        return redirect(route('home') . '#contact')
            ->with('status', __('site.thanks', ['name' => $data['name']]));
    }
}
