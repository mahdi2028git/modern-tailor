<?php

use App\Http\Controllers\PageController;
use Illuminate\Support\Facades\Route;

Route::get('/', [PageController::class, 'home'])->name('home');
Route::get('/lang/{locale}', [PageController::class, 'setLocale'])
    ->whereIn('locale', ['en', 'fa'])
    ->name('lang');
Route::post('/contact', [PageController::class, 'contact'])->name('contact');
